import { Component, OnInit } from "@angular/core";
import { PopoverController } from "@ionic/angular";

@Component({
  selector: "app-popover-content",
  templateUrl: "./popover-content.component.html",
  styleUrls: ["./popover-content.component.scss"],
})
export class PopoverContentComponent implements OnInit {
  constructor(private popoverController: PopoverController) {}

  ngOnInit() {}

  dismissPopover() {
    this.popoverController.dismiss();
  }
}
