import { Component } from "@angular/core";
import { PopoverController, ToastController } from "@ionic/angular";
import { PopoverContentComponent } from "../popover-content/popover-content.component";

@Component({
  selector: "app-home",
  templateUrl: "home.page.html",
  styleUrls: ["home.page.scss"],
})
export class HomePage {
  constructor(
    public toastController: ToastController,
    public popoverController: PopoverController
  ) {}

  async showToast() {
    const toast = await this.toastController.create({
      message: "Ini toast dengan header.",
      header: "Halo!",
      duration: 2000,
      buttons: [
        {
          text: "Tutup",
          role: "cancel",
        },
      ],
    });
    toast.present();
  }

  async showPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: PopoverContentComponent,
      cssClass: "my-custom-class",
      event: ev,
      translucent: true,
      backdropDismiss: false,
    });
    return await popover.present();
  }
}
